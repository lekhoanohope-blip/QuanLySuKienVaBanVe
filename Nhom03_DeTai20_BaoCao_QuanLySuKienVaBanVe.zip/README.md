# Báo cáo đồ án Quản lý Sự kiện và Bán vé Concert

Mã nguồn LaTeX của báo cáo Nhóm 3, học phần COMP1019 - Lập trình trên Windows, Trường Đại học Sư phạm TP.HCM.

**Tệp chính:** `BaoCao_QuanLySuKienVaBanVeConcert_Nhom3.tex`  
**Trình biên dịch:** XeLaTeX  
**Bố cục:** 5 chương, tài liệu tham khảo và phụ lục A-C.

## Cấu trúc thư mục

```text
Report-Latex/
├── BaoCao_QuanLySuKienVaBanVeConcert_Nhom3.tex  # Tệp chính, bìa và cấu hình chung
├── hcmue-concert-report.sty                   # Định dạng trang và bìa
├── .latexmkrc                                # Cấu hình XeLaTeX cho latexmk
├── frontmatter/
│   └── danh-muc-viet-tat.tex
├── chapter/
│   ├── 01-tong-quan-va-phan-tich-yeu-cau.tex
│   ├── 02-thiet-ke-co-so-du-lieu.tex
│   ├── 03-kien-truc-va-to-chuc-ma-nguon.tex
│   ├── 04-giao-dien-va-chuc-nang.tex
│   └── 05-kiem-thu-trien-khai-va-huong-phat-trien.tex
├── appendices/
│   └── phu-luc-cai-dat-va-demo.tex             # Phụ lục A, B và C
├── fonts/                                    # Times New Roman: thường, đậm, nghiêng, đậm nghiêng
├── img/                                      # Ảnh PNG gốc và các hình PDF dùng trong báo cáo
└── figures/                                  # Mã TikZ và công cụ tạo PDF từ PNG
```

Chỉnh nội dung trong `chapter/` hoặc `appendices/`. Thông tin bìa, bảng phân công, phần mở đầu và tài liệu tham khảo nằm trong tệp chính. Hướng dẫn cập nhật hình được tách tại [figures/README.md](figures/README.md).

## Biên dịch trên Overleaf

1. Tải mã nguồn lên, giữ nguyên cấu trúc thư mục và các tệp font, hình ảnh.
2. Đặt **Main document** là `BaoCao_QuanLySuKienVaBanVeConcert_Nhom3.tex`.
3. Chọn **Compiler: XeLaTeX**, biên dịch ở chế độ **Normal**.
4. Kiểm tra PDF và log, sau đó tải bản PDF để bàn giao.

Sơ đồ kiến trúc được biên dịch riêng thành PDF; ảnh chụp màn hình cũng dùng bản PDF tạo từ PNG. Giữ cách chèn này để giảm công việc xử lý hình khi biên dịch trên Overleaf Free. Chỉ tạo lại các tệp hình PDF khi nguồn tương ứng thay đổi.

Khi gặp giới hạn thời gian biên dịch, kiểm tra lỗi đầu tiên trong log và các hình vừa thêm. Nếu chỉ sai số trang hoặc dẫn chiếu, thử biên dịch lại. Dùng **Recompile from scratch** khi cần loại dữ liệu phụ cũ, chẳng hạn sau khi đổi trình biên dịch; thao tác này phải dựng lại toàn bộ báo cáo.

## Biên dịch tại máy

Mở terminal tại `Report/Report-Latex`. Với máy đã có TeX Live hoặc MiKTeX và `latexmk`, chạy:

```powershell
latexmk -xelatex -interaction=nonstopmode -halt-on-error BaoCao_QuanLySuKienVaBanVeConcert_Nhom3.tex
```

Hoặc dùng Tectonic:

```powershell
tectonic -X compile BaoCao_QuanLySuKienVaBanVeConcert_Nhom3.tex
```

PDF đầu ra mang tên `BaoCao_QuanLySuKienVaBanVeConcert_Nhom3.pdf`. Chạy lệnh từ đúng thư mục để các đường dẫn `fonts/`, `img/` và `chapter/` được tìm thấy.

## Quy cách trình bày hiện tại

| Thành phần | Thiết lập |
|---|---|
| Khổ giấy và lề | A4 dọc, một mặt; trên/dưới/trái 2,5 cm, phải 2 cm |
| Nội dung | Times New Roman 13 pt, UTF-8, giãn dòng 1,5 |
| Đoạn văn | Căn đều hai bên, thụt đầu dòng 1 cm |
| Bảng và hình | Đánh số theo chương; tên bảng ở trên, tên hình ở dưới |
| Mục lục | Tạo tự động, có dấu chấm dẫn đến số trang |
| Số trang | Bìa không số; phần đầu dùng La Mã nhỏ; từ Chương 1 dùng số Ả Rập |
| Tài liệu tham khảo | `thebibliography`, dẫn nguồn bằng `\cite{...}`, đặt trước phụ lục |

Đây là cấu hình của bản báo cáo nhóm. Khi đổi font, lề hoặc cỡ chữ, kiểm tra lại bảng, listing, hình và ngắt trang.

## Quy ước biên tập

- Dùng `\chapter`, `\section`, `\subsection` để tạo tiêu đề; để LaTeX đánh số mục.
- Đặt `\label` ngay sau `\caption`; dùng `\ref{...}` để dẫn chiếu. Giữ mỗi nhãn duy nhất trong báo cáo.
- Bảng một trang chủ yếu dùng `tabular` với cột `p{...}` hoặc độ rộng tính từ `\textwidth`. Bảng `KhuVuc` ở Chương 2 dùng `xltabular`. Khi đổi cột, kiểm tra lại tổng độ rộng; không đổi đồng loạt sang `tabularx` vì mỗi bảng cần thêm các lượt dàn thử.
- Mã C#/SQL đặt trong `lstlisting`. Với chú thích hoặc chuỗi tiếng Việt, dùng các macro `\vncmt` và `\vnstr` theo mẫu đang có trong các chương.
- Tên Form, lớp, hàm, thuộc tính và script phải khớp mã nguồn ứng dụng. Phân biệt kết quả Unit Tests với kết quả kiểm thử thủ công; chỉ ghi “Pass” khi có kết quả thực thi.
- Thêm nguồn bằng `\bibitem{...}` và dẫn bằng `\cite{...}`. Bản hiện tại dùng `thebibliography` trực tiếp trong tệp chính.

## Đồng bộ với Overleaf

Công cụ nằm ở thư mục `Report/sync-overleaf`; xem [hướng dẫn đồng bộ](../sync-overleaf/README.md). Trước khi sửa, lấy các thay đổi mới từ Overleaf. Nếu hai bên đã cùng sửa một tệp, giữ bản sao và gộp nội dung trước khi đẩy; `push_file.py` đẩy bản được chọn, không tự gộp nội dung.

Ví dụ, từ `Report/Report-Latex`, đẩy riêng một chương:

```powershell
python ../sync-overleaf/push_file.py chapter/04-giao-dien-va-chuc-nang.tex
```

Khi cập nhật ảnh, đồng bộ PNG gốc, PDF tương ứng và tệp `.tex` nếu có thay đổi cách chèn hình. Không đưa `.olauth` (phiên đăng nhập), `.olsync-state.json` hoặc các tệp phụ biên dịch vào gói mã nguồn bàn giao.
