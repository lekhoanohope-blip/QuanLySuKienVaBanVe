# Hình minh họa của báo cáo

Thư mục này giữ mã nguồn sơ đồ và công cụ tạo hình PDF. Báo cáo chèn hình từ `../img/`; các đường dẫn trong LaTeX được tính từ thư mục gốc `Report-Latex`.

| Tệp/thư mục | Vai trò |
|---|---|
| `kien-truc-3-tang.tex` | Mã TikZ của sơ đồ GUI-BLL-DAL và DTO |
| `build_image_pdfs.py` | Tạo PDF từ các ảnh PNG trong `img/` |
| `../img/kien-truc-3-tang.pdf` | Sơ đồ kiến trúc được Chương 3 chèn vào báo cáo |
| `../img/*.png`, `../img/*.pdf` | Ảnh nguồn và bản PDF tương ứng |

## Thêm hoặc thay ảnh PNG

Các lệnh trong phần này chạy từ **thư mục gốc `Report-Latex`**.

1. Đặt ảnh PNG vào `img/`, dùng tên mô tả màn hình, chẳng hạn `frm_inve.png`.
2. Cài các thư viện Python nếu máy chưa có:

   ```powershell
   python -m pip install Pillow pypdf
   ```

3. Tạo lại các bản PDF:

   ```powershell
   python figures/build_image_pdfs.py
   ```

   Script quét toàn bộ `img/*.png` và ghi lại PDF cùng tên. Ví dụ: `img/frm_inve.png` tạo `img/frm_inve.pdf`. Ảnh bitmap trong PDF giữ nguyên số pixel, dữ liệu RGB và độ trong suốt; script kiểm tra lại dữ liệu sau khi ghi.

4. Chèn bản PDF vào chương tương ứng. Ví dụ đang dùng ở mục 4.6.2:

   ```latex
   \begin{figure}[H]
       \centering
       \includegraphics[width=\textwidth]{img/frm_inve.pdf}
       \caption{Màn hình xem trước vé với mã vạch Code 128 và các nút in vé, xuất PDF (FrmInVe)}
       \label{fig:frm_inve}
   \end{figure}
   ```

5. Biên dịch báo cáo, kiểm tra ảnh và chú thích trên PDF. Nếu thêm hình mới, đặt nhãn riêng và dẫn chiếu bằng `\ref{...}`; số hình do LaTeX tạo.

Giữ PNG làm nguồn để cập nhật sau này. Bản PDF giúp XeLaTeX giảm việc giải mã và nén lại PNG trong mỗi lần biên dịch báo cáo.

## Sửa sơ đồ kiến trúc

Sửa `kien-truc-3-tang.tex`, sau đó mở terminal tại **thư mục `figures/`** và chọn một trong hai lệnh:

```powershell
xelatex -interaction=nonstopmode -halt-on-error -output-directory=../img kien-truc-3-tang.tex
```

```powershell
tectonic -X compile --outdir ../img kien-truc-3-tang.tex
```

Cả hai lệnh tạo `../img/kien-truc-3-tang.pdf`, tính từ `figures/`. Nguồn sơ đồ dùng font từ `../fonts/`, nên cần chạy tại đúng thư mục. Kiểm tra PDF sơ đồ rồi biên dịch lại báo cáo chính từ thư mục gốc.

Chương 3 dùng `\includegraphics{img/kien-truc-3-tang.pdf}`. Chỉ dựng lại sơ đồ khi sửa mã TikZ; bản báo cáo chính sử dụng PDF đã tạo để giảm thời gian biên dịch.

## Đồng bộ sau khi cập nhật hình

| Thay đổi | Tệp cần đồng bộ |
|---|---|
| Thay ảnh có sẵn | PNG nguồn và PDF cùng tên |
| Thêm ảnh mới | PNG, PDF và tệp chương `.tex` liên quan |
| Sửa chú thích, kích thước hoặc nhãn | Tệp `.tex` chứa hình |
| Sửa sơ đồ kiến trúc | `figures/kien-truc-3-tang.tex` và `img/kien-truc-3-tang.pdf` |

Ví dụ, chạy từ **thư mục gốc `Report-Latex`**:

```powershell
python ../sync-overleaf/push_file.py img/frm_inve.png img/frm_inve.pdf chapter/04-giao-dien-va-chuc-nang.tex
```

Đối chiếu thay đổi của các thành viên trước khi đẩy tệp. Hướng dẫn biên dịch, quy cách bảng và quy trình biên tập chung nằm trong [README của báo cáo](../README.md).
