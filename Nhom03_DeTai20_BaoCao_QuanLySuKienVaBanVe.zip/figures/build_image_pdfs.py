"""Wrap original PNG pixels in PDFs for faster XeLaTeX builds.

Run: python figures/build_image_pdfs.py
Dependencies: Pillow, pypdf. Original PNG files are retained.
"""

from pathlib import Path
import zlib

from PIL import Image
from pypdf import PdfReader, PdfWriter
from pypdf.generic import (
    DecodedStreamObject,
    DictionaryObject,
    EncodedStreamObject,
    NameObject,
    NumberObject,
)


def image_stream(pixels, width, height, colorspace):
    stream = EncodedStreamObject()
    stream._data = zlib.compress(pixels, level=6)
    stream.update({
        NameObject('/Type'): NameObject('/XObject'),
        NameObject('/Subtype'): NameObject('/Image'),
        NameObject('/Width'): NumberObject(width),
        NameObject('/Height'): NumberObject(height),
        NameObject('/ColorSpace'): NameObject(colorspace),
        NameObject('/BitsPerComponent'): NumberObject(8),
        NameObject('/Filter'): NameObject('/FlateDecode'),
    })
    return stream


def convert(source):
    with Image.open(source) as original:
        rgba = original.convert('RGBA')
        rgb = rgba.convert('RGB').tobytes()
        alpha = rgba.getchannel('A')
        width, height = rgba.size

    writer = PdfWriter()
    page_width, page_height = width * 0.75, height * 0.75
    page = writer.add_blank_page(width=page_width, height=page_height)
    image = image_stream(rgb, width, height, '/DeviceRGB')
    if alpha.getextrema() != (255, 255):
        mask = image_stream(alpha.tobytes(), width, height, '/DeviceGray')
        image[NameObject('/SMask')] = writer._add_object(mask)
    reference = writer._add_object(image)
    page[NameObject('/Resources')] = DictionaryObject({
        NameObject('/XObject'): DictionaryObject({NameObject('/Im0'): reference}),
    })
    content = DecodedStreamObject()
    content.set_data(
        f'q {page_width:g} 0 0 {page_height:g} 0 0 cm /Im0 Do Q'.encode('ascii')
    )
    page[NameObject('/Contents')] = writer._add_object(content)
    destination = source.with_suffix('.pdf')
    with destination.open('wb') as output:
        writer.write(output)

    # Verify the PDF stores exactly the original color and opacity samples.
    saved = PdfReader(destination).pages[0]['/Resources']['/XObject']['/Im0']
    assert saved.get_data() == rgb, source.name
    if '/SMask' in saved:
        assert saved['/SMask'].get_data() == alpha.tobytes(), source.name
    print(f'{source.name} -> {destination.name}: original pixels retained')


if __name__ == '__main__':
    for source in sorted((Path(__file__).resolve().parent.parent / 'img').glob('*.png')):
        convert(source)
