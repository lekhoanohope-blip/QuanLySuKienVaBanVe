# XeLaTeX is required for Unicode and the bundled Times New Roman fonts.
$pdf_mode = 5;
